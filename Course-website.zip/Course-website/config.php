<?php 

$con=new mysqli("localhost","root","","trade");
if($con->connect_error)
{
	echo "Database Connection Failed";
}

?>