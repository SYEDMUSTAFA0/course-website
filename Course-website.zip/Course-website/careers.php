<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Career Opportunities</title>
    <link rel="stylesheet" href="css/styles.css">
    <!-- Optional: Include Bootstrap CSS for additional styling -->
</head>
<style>
    div#navbarCollapse{
        justify-content:end;
    }
</style>
<body>
  
    <!-- Navbar Start -->
    <?php include 'includes/navbar.php';  ?>



    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Join Our Team</h6>
                <h1 class="mb-5">Career Opportunities</h1>
            </div>
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="job-item bg-light p-4">
                        <h5>Frontend Developer</h5>
                        <p><strong>Location:</strong> Bangalore</p>
                        <p><strong>Type:</strong> Full-Time</p>
                        <p><strong>Experience:</strong> 2+ years</p>
                        <p>We are looking for a skilled Frontend Developer with experience in HTML, CSS, and JavaScript. Join our team and work on exciting projects!</p>
                        <a href="#" class="btn btn-primary">Apply Now</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="job-item bg-light p-4">
                        <h5>Backend Developer</h5>
                        <p><strong>Location:</strong> Bangalore</p>
                        <p><strong>Type:</strong> Full-Time</p>
                        <p><strong>Experience:</strong> 3+ years</p>
                        <p>We are seeking a Backend Developer proficient in .NET and SQL Server. Work with our dynamic team to build robust backend systems.</p>
                        <a href="#" class="btn btn-primary">Apply Now</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="job-item bg-light p-4">
                        <h5>UI/UX Designer</h5>
                        <p><strong>Location:</strong> Remote</p>
                        <p><strong>Type:</strong> Part-Time</p>
                        <p><strong>Experience:</strong> 1+ years</p>
                        <p>We are looking for a creative UI/UX Designer to create intuitive and engaging user experiences. Work remotely with our global team.</p>
                        <a href="#" class="btn btn-primary">Apply Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-xxl py-5 bg-light">
        <div class="container">
            <div class="text-center">
                <h2 class="mb-4">Why Work With Us?</h2>
                <div class="row">
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="feature-item">
                            <i class="fa fa-heart text-primary"></i>
                            <h5 class="mt-3">Great Work Environment</h5>
                            <p>Join a company that values a positive and supportive work culture.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="feature-item">
                            <i class="fa fa-dollar-sign text-primary"></i>
                            <h5 class="mt-3">Competitive Salaries</h5>
                            <p>We offer competitive salaries and comprehensive benefits packages.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="feature-item">
                            <i class="fa fa-graduation-cap text-primary"></i>
                            <h5 class="mt-3">Learning Opportunities</h5>
                            <p>Take advantage of continuous learning and career development opportunities.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

   
    <!-- Footer Start -->
    <?php include 'includes/footer.php';  ?>
    <!-- Footer End -->

    <!-- Optional: Include Bootstrap JS and dependencies -->
</body>
</html>
